# Блоки

## lib/with_numbers.rb

Реализуйте функцию `with_numbers()`.
