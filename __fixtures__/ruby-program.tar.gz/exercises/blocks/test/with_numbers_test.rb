# frozen_string_literal: true

require_relative 'test_helper'
require_relative '../lib/with_numbers'

class WithNumbersTest < Minitest::Test
  def test_with_numbers_output
    assert_output(/result is 6/) do
      with_numbers 3, 2 do |first, second|
        puts "result is #{first * second}"
      end
    end
  end
end
