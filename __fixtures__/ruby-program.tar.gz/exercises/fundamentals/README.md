# Основы

## lib/reverse.rb

Реализуйте функцию `reverse()`.

## lib/sum_of_primes.rb

Напишите функцию `sum_of_primes()`.

### Подсказки
