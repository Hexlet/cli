# frozen_string_literal: true

def reverse(string)
  # BEGIN
  
  # END
end

# BEGIN

# END
