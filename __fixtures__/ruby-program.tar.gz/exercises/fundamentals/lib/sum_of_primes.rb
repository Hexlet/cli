# frozen_string_literal: true

require 'prime'

def sum_of_primes(num)
  # BEGIN
  
  # END
end
