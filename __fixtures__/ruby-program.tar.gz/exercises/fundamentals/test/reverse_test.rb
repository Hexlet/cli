# frozen_string_literal: true

require_relative 'test_helper'
require_relative '../lib/reverse'

class ReverseTest < Minitest::Test
  def test_revers_one_word
    assert_equal 'telxeH', reverse('Hexlet')
  end
end
