# frozen_string_literal: true

require_relative 'test_helper'
require_relative '../lib/sum_of_primes'

class SumOfPrimesTest < Minitest::Test
  def test_sum_of_primes
    assert_nil sum_of_primes(-1)
    assert_equal 0, sum_of_primes(0)
    assert_equal 0, sum_of_primes(1)
  end
end
